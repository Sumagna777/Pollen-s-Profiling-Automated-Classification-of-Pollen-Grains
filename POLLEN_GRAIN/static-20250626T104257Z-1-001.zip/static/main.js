console.log("JavaScript loaded.");
